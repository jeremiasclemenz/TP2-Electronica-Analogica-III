Using of Infineon Symbols File

Infineon Symbols File provides possibility to see Infineon symbols for schematic presentation of Infineon components.
One need to perform following steps to add symbols to AWR Design Environment.

1. Save and open zip archive.
1. Copy infineon_32.syf to <AWR Installation Folder>\Symbols to currently used MWO installation.
2. Restart the MWO Design Environment to see the effect of added symbols for Infineon library elements.

(c) Infineon Technologies, November 2012
